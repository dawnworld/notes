xcode5 导入 makefile
---
### mac 调试
用mac 有一段时间，刚开始的时候只是用它做些代码编辑工作之类的，后来就把自己的大部分windows上的工作都移过来了，但有一项一直感觉很别扭，是什么呢？那就是调试！

话说调试，windows 上的 visual studio 调试代码很强大，使用起来也很方便，对于代码调试帮助很大。linux 上的gdb 也很强大，之前对其有点误会，后来在看了它的manual 后发现功能也很给力，但单步调试的时候每次去打`n`  `p` 总感觉很麻烦。既然用mac 了，就得去学习xcode，在搜索资料后终于找到一个方法 `导入makefile 进行调试`。
<!-- more -->

### 前期准备
既然我们说导入makefile 的话，那肯定 得先准备好，Ready, GO！

### 导入参考
* 建立一个其它编译方式的项目
![Alt text](./import_make_1.png)
* 填入相关相信
![fill info](./import_make_2.png)
* 选择 makefile 的工作目录
![choose make work directory](./import_make_3.png)
* 导入需要工作文件，注意下方的添加方式，只添加索引即可
![Alt text](./import_make_4.png)
* 选择Product 菜单，编辑 Scheme
![Alt text](./import_make_5.png)
* 选择执行待调试程序
![Alt text](./import_make_6.png)
* 打上断点，小伙伴们开始调试吧
![Alt text](./import_make_7.png)

### 总结
xcode 作为mac 下的首席开发工具，自有它的运用之道，在平常使用中，我们应该少埋怨它的不足，多去挖掘它的潜力，这样经常就会有意想不到的结果。